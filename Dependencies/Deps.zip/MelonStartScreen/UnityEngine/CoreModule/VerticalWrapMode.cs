﻿namespace MelonUnityEngine
{
    internal enum VerticalWrapMode
    {
        Truncate,
        Overflow
    }
}
