﻿namespace MelonUnityEngine
{
    internal enum FilterMode
    {
        Point,
        Bilinear,
        Trilinear
    }
}
