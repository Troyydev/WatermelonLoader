﻿namespace MelonUnityEngine
{
	internal enum FontStyle
	{
		Normal,
		Bold,
		Italic,
		BoldAndItalic
	}
}
